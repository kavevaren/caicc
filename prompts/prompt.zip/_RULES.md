# Agent rules (read once; every phase prompt assumes them)

You build **Orvina** from `docs/SPEC.md` (functional + architecture) and `docs/design/DESIGN.md` (UI + motion). The static target is `docs/design/dashboard-mockup.html`. If anything here conflicts with a phase prompt, the phase prompt wins; if the SPEC is unclear, ask before coding.

## Non-negotiable (SPEC §2; any break disqualifies us)
1. **LLMs:**
   - Only `zai-org/GLM-5.2`, `deepseek-ai/DeepSeek-V4-Pro-0813`, `stepfun-ai/Step-3.5-Flash` and `Qwen/Qwen3.8-27B`, via `https://api-inference.modelscope.ai/v1`.
   - Only the Python engine calls them.
2. **No other AI services:** no proprietary AI service and no Web Speech API, anywhere. Speech-to-text is faster-whisper on CPU only.
3. **No training, no fine-tuning, no GPU.**
4. **Secrets:** from environment variables only. Never in code, logs, tests, the web bundle or commits.
5. **Code authorship:** you write all code. Never write the `MANUAL` marker.
6. **No new dependencies without asking.** Only what SPEC §3.1 lists.

## Way of working
- **Languages:**
  - TypeScript in `web/`, Go in `gateway/`, Python in `engine/`, SQL in `gateway/internal/migrations/`.
  - Contracts in `contracts/*.yaml` are the source of truth between them. Change a contract first, then all sides.
- **Before saying "done":**
  - run `make test lint build` (go test/vet, pytest/ruff, vitest/eslint/tsc);
  - **open the affected page in a browser and click through it.** Tests passing is not done.
- **Every bug fix gets a regression test** in the language where the bug lived.
- **User-facing errors** are translated JSON (`{"error":{"code","message_key"}}`) shown with "Coba lagi". A stack trace must never reach the browser.
- **Text:** every UI string comes from `web/src/locales/{id,en,zh}.json`. No emoji. Sentence case.
- **Evidence (50% of our score is ModelScope usage and prompting iteration):** after each phase, append to `prompt-log.md`:
  - the date and phase;
  - the prompt you received (file name);
  - your summary;
  - the fixes;
  - test output and screenshot paths.

  Also update `docs/PROGRESS.md`.
- **Ambiguity:** ask one precise question instead of guessing on anything that is costly to undo.

## Report format (end of every phase, then stop and wait for "lanjut")
1. **Files changed** (one line each, with the reason).
2. **Test output** (each language) and build result.
3. **Acceptance:** one line per "Done when" item: done / not done + why.
4. **Screenshots or recordings** where the phase asks for them.
5. **Risks and open questions.**
6. **Proposed next step.**

# P0 · Prove the platform (Fri 30 Oct, ≤ 3 h)

**Read:** `prompts/_RULES.md`, `docs/SPEC.md` §3, §4.1, §13.
**Goal:** before building anything real, prove that one Docker image with Go + Python + a React page runs on ModelScope Studio and that the browser features we depend on work there.

## Tasks
1. **Inspect the folder.**
   - Report whether it already contains the old Streamlit repo (`core/`, `services/`, `app.py`) or is empty.
   - If it is a git repo with the old app, tag the current commit `streamlit-v1` (our fallback submission). Do not delete anything yet.
2. **Hello stack**, using the target layout (SPEC §4):
   - `gateway/` (Go):
     - serves `web/dist`;
     - `GET /api/health`;
     - a WebSocket echo at `/ws/echo`;
     - starts the engine as a child process and reports its health.
   - `engine/` (Python 3.10, FastAPI on 127.0.0.1:8001):
     - `GET /v1/health` makes one tiny FAST call to ModelScope and reports `ok` / `invalid_token` / `unreachable`;
     - loads whisper `tiny` once and reports `ready`.
   - `web/` (React + Vite + TypeScript + motion):
     - one page with the AtomLoader (the logo's two ellipses counter-rotating);
     - the health JSON;
     - a WebSocket echo test;
     - a mic level meter (`getUserMedia` + `AudioContext`);
     - a fullscreen test button;
     - a "test PiP" button (`documentPictureInPicture.requestWindow`).
3. **Dockerfile** (3 stages, SPEC §13) + `ms_deploy.json` (`sdk_type: docker`, port 7860), `.dockerignore`, `.env.example`.
4. **Deploy to a separate test Studio** (not the final one). The token goes in Studio Secrets.

## Done when
- [ ] The image builds locally and on the Studio. Report the image size and cold-start time.
- [ ] Health shows `gateway ok · engine ok · modelscope ok · whisper ready` on the deployed URL (with the real token).
- [ ] A results table, **inside the Studio page** vs **on the direct app URL**, for: WebSocket, mic, fullscreen, PiP, `localStorage`.
- [ ] Peak RAM of the container with the engine idle and with whisper `tiny` loaded.

**Stop immediately if the Studio does not accept Docker.** Report what it offers; we will choose the fallback in SPEC §13.

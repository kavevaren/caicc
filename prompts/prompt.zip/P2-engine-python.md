# P2 · AI engine in Python (Sat 31 Oct) · lane A, can run in parallel with P3 and P4

**Read:** `_RULES.md`, SPEC §3.2 (stateless engine), §7, §9.1–§9.2, §9.5, §10, §12 (Python).
**Goal:** a stateless FastAPI service that implements `contracts/engine.yaml` exactly, reusing the already-tested AI code.

## Reuse (if the old repo is present)
- Move into `engine/orvina_engine/`:
  - `core/llm.py`, `core/prompts.py`, `core/schemas.py`;
  - `services/extract.py`, `media.py`, `transcribe.py`, `summarize.py`, `figures.py`, `charts.py`, `meeting.py`;
  - the AI parts of `services/forum.py`.
- Keep their tests and make them pass in the new place.
- Then remove every database and Streamlit dependency from this code:
  - calls are recorded into a per-request `ai_calls` list instead of the DB;
  - `st.cache_resource` becomes `functools.lru_cache`;
  - figures are written to `DATA_DIR/figures/<job_id>/` and returned as paths.
- **If the folder is empty:** build these modules from SPEC §9–§10 instead and tell me first (this adds about one day).

## Tasks
1. **`engine/main.py`:**
   - routes from `engine.yaml`;
   - an `X-Engine-Key` dependency (reject with 401);
   - bind to `127.0.0.1`;
   - a global exception handler that returns `{"type":"error","code"}` or JSON errors, never a traceback.
2. **NDJSON streaming** for `/v1/summarize` and `/v1/transcribe`:
   - one `stage` line when each stage starts;
   - one final `result` or `error` line;
   - heavy work in a thread pool, so the event loop stays free;
   - flush after each line.
3. **LLM client** (SPEC §9.1): a 401 raises `ModelScopeAuthError` with no retry, and `/v1/health` reports `invalid_token`.
4. **`/v1/live/chunk`** (SPEC §10.5):
   - decode Int16 PCM, skip silent chunks (RMS) with no model call;
   - whisper `LIVE_WHISPER_MODEL` under the global lock, `initial_prompt` from `X-Context`;
   - FAST translation (skipped when source = target);
   - return timings.
5. **Duration probe:** `media_too_long` error with the real duration in minutes.
6. **`scripts/smoke_test.py`** (SPEC §12) against the real API.

## Done when
- [ ] `pytest` (fake LLM) passes, including the chart-safety cases and the contract tests against `engine.yaml`.
- [ ] Smoke test table: 4 models OK with latency, VISION formula image OK, whisper loads and reports its source.
- [ ] One real run of each endpoint on sample files (a PDF with formulas, a PPTX with a repeated logo, a 1-minute speech clip). Report:
  - candidates → filtered → selected figures;
  - charts drawn;
  - VISION calls;
  - seconds per stage;
  - a live chunk round trip (transcribe ms, translate ms).
- [ ] `grep` shows no `streamlit`, no `sqlite3` and no model ID outside `llm.py`/`config.py` in `engine/`.

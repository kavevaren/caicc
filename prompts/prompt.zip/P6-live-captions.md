# P6 · Live captions: Presentasi langsung (Tue 3 Nov)

**Read:** `_RULES.md`, SPEC §9.5, §10.5, DESIGN §4.4 (caption bar).
**Goal:** while a student presents, show a live transcript + translation as captions on their slides inside Orvina, and in a floating window that stays above PowerPoint fullscreen. Engine side done in P2, gateway side in P3; this phase is the browser plus end-to-end tuning.

## Tasks
1. **`features/live/pcm-worklet.ts`:** an AudioWorklet that downsamples to 16 kHz mono Int16. Every `LIVE_CHUNK_SECONDS` it sends one binary frame: an 8-byte little-endian header (uint32 seq, uint16 slide_index, uint16 0) + PCM.
   - No MediaRecorder. **No Web Speech API** (compliance test must stay green).
2. **`useLiveSocket`:**
   - ws-ticket, then the `start` frame;
   - send chunks;
   - handle `caption`, `status: catching_up`, `saved`, `error`, `live_busy`;
   - reconnect once.
3. **Setup screen:**
   - PDF picker: slides render client-side with react-pdf and are never uploaded;
   - source language (auto/id/en/zh) and target language;
   - caption size S/M/L;
   - toggles "Tampilkan teks asli" and "Teks melayang";
   - a mic level check.
4. **`SlideViewer`:** fills the screen; arrow keys and on-screen buttons; Fullscreen API; current `slide_index` sent with each chunk.
5. **`CaptionBar`** (DESIGN §4.4): last 2 lines, translation big and original small, a slide-up entrance, a listening dot, Pause/Resume, Stop.
6. **`PipOverlay`:**
   - `documentPictureInPicture.requestWindow({width:900, height:170})` on click;
   - `CaptionBar` rendered into it with a React portal, with the stylesheets copied in;
   - fallback `window.open` pop-out plus one line "Jendela ini tidak bisa selalu di atas aplikasi lain.";
   - a one-time tip: "Buka teks melayang, lalu mulai slideshow PowerPoint. Teksnya tetap di atas."
7. **Iframe guard:** when `window.top !== window` (inside the Studio) or a permission fails, show "Buka di tab baru" linking to `PUBLIC_APP_URL/transcribe?mode=live`.
8. **After stop:** a session summary (duration, segments, average delay), a link to the saved transcript, and the button "Buat ringkasan & action items" (meeting job).

## Done when (report each as pass/fail)
- [ ] Chrome and Edge on Windows: the floating captions stay above **PowerPoint fullscreen**.
- [ ] Presentation mode fullscreen with arrow keys; captions at size L readable from 3 m.
- [ ] Firefox shows the pop-out fallback with its notice.
- [ ] Indonesian speech → 中文 captions; English speech → Indonesian.
- [ ] Two live sessions at once do not break the app; the 4th session gets `live_busy`.
- [ ] Latency table for 10 chunks on the deployed Studio: transcribe ms, translate ms, total delay. Target total < 6 s; if above, report what to tune (chunk length, `tiny` model, skip translation of short chunks).

**If PiP is blocked even on the direct URL,** ship slide captions + the pop-out only, and tell me.

# P7 · Polish, compliance, deploy, evidence (Tue 3 Nov night → submit Wed 4 Nov by 23:59 WIB)

**Read:** `_RULES.md`, SPEC §2, §12, §13.
**Goal:** a stable public Studio, a clean repo, and complete evidence for the judges.

## Tasks
1. **Remove leftovers:** Streamlit code, mocks from the production build, unused deps, `data-test/` and other committed test output. `streamlit-v1` stays as a tag only.
2. **`make compliance` green.** It fails on:
   - any non-allowed model ID, or an LLM call outside `engine/`;
   - a forbidden AI domain, or `SpeechRecognition` / `webkitSpeechRecognition`;
   - a token-like string;
   - emoji in UI strings;
   - more than 30 `MANUAL` lines.

   Print the `MANUAL` count.
3. **Full test run:**
   - go test, pytest, vitest, eslint, tsc, build;
   - Playwright e2e of the full loop **on the deployed Studio URL**;
   - Lighthouse on the Dashboard (Performance ≥ 85, Accessibility ≥ 95).
4. **Studio:**
   - final Docker deploy;
   - Secrets set (`MODELSCOPE_TOKEN`, `APP_SECRET_KEY`, Google vars if used, `PUBLIC_APP_URL`);
   - visibility **Public**;
   - seed loaded;
   - health all green.

   A 20-user load check (dashboard, forum, one summary job) without errors.
5. **README:**
   - Orvina lockup, one-paragraph pitch, screenshots;
   - architecture (SPEC §3.2) with the **language-per-layer table and why**;
   - setup (Docker + `make dev`), environment variables, Studio Secrets, Google Cloud steps;
   - model roles;
   - a **Competition compliance** table (each rule in SPEC §2 → where the code enforces it);
   - open-source libraries + licenses;
   - Apache-2.0.
6. **Evidence pack** (`docs/evidence/`):
   - `prompt-log.md` complete;
   - the 2–3 key prompts as a PDF: SPEC v4 (short), `P2-engine-python.md` (the AI prompt design), and one fix iteration (the 30 Oct browser test → P5 acceptance list);
   - agent screenshots with the model name visible;
   - the smoke-test table;
   - Lighthouse reports;
   - a 60–90 second demo video script.
7. **`docs/PROGRESS.md`** final, with known limits stated honestly (e.g. the free CPU makes long videos slow; the Google OAuth consent screen is in test mode).

## Done when
- [ ] The Studio URL works for a fresh user in an incognito window, from register to the full loop.
- [ ] All checks above are green, with their outputs pasted in the report.
- [ ] A submission checklist for me: Studio link, project zip (no `.env`, no data), prompts PDF, screenshots folder. Each item ticked.

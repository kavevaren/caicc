# P1 · Contracts, schema and skeleton (Fri 30 Oct night, ≤ 4 h)

**Read:** `_RULES.md`, SPEC §3–§7, §12.
**Goal:** write the contracts that let three languages be built in parallel (P2 engine, P3 gateway, P4 web) without drifting.

## Tasks
1. **`contracts/openapi.yaml`**: every public endpoint in SPEC §6, with:
   - request and response schemas;
   - error codes per endpoint;
   - `bearerAuth`;
   - the SSE event shapes.

   Include the bug-driven rules as schema constraints:
   - question title 10–150 characters;
   - event `end_at` after `start_at`;
   - `accept_terms` must be true.
2. **`contracts/engine.yaml`**: every engine endpoint in SPEC §7, including:
   - NDJSON line schemas (`stage`, `result`, `error`);
   - the `ai_calls` item;
   - the `X-Engine-Key` header.
3. **SQL migrations:** `gateway/internal/migrations/001_init.sql` with every table, index, FTS5 table and sync trigger in SPEC §5. Explicit column lists everywhere.
4. **Generated types and mocks:**
   - `web/src/lib/api-types.ts` from `openapi.yaml` (`openapi-typescript`);
   - an MSW mock layer (`web/src/mocks/`) returning realistic Indonesian sample data (the mockup's data), so P4 can work before the gateway exists.
5. **Project tooling:**
   - `Makefile` (`dev`, `test`, `lint`, `build`, `e2e`, `compliance`, `docker`);
   - `scripts/compliance.py` (SPEC §12 Compliance), already passing on the skeleton;
   - `README.md` stub with the architecture diagram from SPEC §3.2;
   - `prompt-log.md`.
6. **Contract tests wired:**
   - Go: a request/response validator middleware in tests;
   - Python: schemathesis (or equivalent) against `engine.yaml`;
   - TS: `tsc` on the generated types.
7. **Docs:** copy `SPEC.md`, `DESIGN.md`, `dashboard-mockup.html` and the brand SVGs into `docs/` and `assets/brand/`.

## Done when
- [ ] Both YAML files validate (`redocly lint` or equivalent), and every endpoint in SPEC §6–§7 is present.
- [ ] `001_init.sql` applies twice on an empty DB without error.
- [ ] `npm run dev` shows the mock-backed app shell with no gateway running.
- [ ] `make compliance` passes.
- [ ] Report: the endpoint count per contract, and anything in the SPEC you found ambiguous.

# P3 · Gateway in Go (Sat 31 Oct – Sun 1 Nov) · lane B, can run in parallel with P2 and P4

**Read:** `_RULES.md`, SPEC §3, §5, §6, §8 (rules per page), §9.3–§9.5, §11, §12 (Go).
**Goal:** a Go 1.22 binary that implements `contracts/openapi.yaml`, owns SQLite and all product rules, runs jobs and live sessions, and supervises the engine.

## Tasks
1. **`cmd/orvina`:**
   - config from the environment (SPEC §4.1);
   - migrations (embedded SQL);
   - the HTTP server on `PORT`;
   - the engine supervisor: start uvicorn, health-poll, restart with backoff, forward its logs with a prefix;
   - a `seed` subcommand (SPEC §12).
2. **Middleware:**
   - request ID and logging (no secrets);
   - **recover → error JSON**;
   - Bearer auth (sha256 token lookup);
   - per-user rate limits;
   - body size limits (SPEC §11).
3. **Handlers per area** (SPEC §6), with the rules from §8 and §11 implemented here:
   - auth (bcrypt cost 12; generic login error; `terms_required`), plus onboarding;
   - the dashboard aggregate: one query set returning real data for all blocks;
   - forum:
     - FTS5 search;
     - similar questions: FTS5 top 10 → engine;
     - tags, moderation and hints → engine;
     - votes (unique, no self-votes), best answer, follow, attachments;
   - points ledger with reversals; leaderboard windows (Monday 00:00 Asia/Jakarta);
   - notifications created on action, with `event_soon` / `rank_change` computed on dashboard load;
   - events:
     - explicit column INSERTs;
     - `end_at` > `start_at`, defaulting to start + 1 h;
     - `.ics` (RFC 5545) and the template link;
     - suggestions accept/dismiss;
   - Google OAuth and Calendar via `x/oauth2` (SPEC §9.3); tokens encrypted with AES-GCM.
4. **Jobs:**
   - `POST /api/summaries` and `/api/transcripts` store uploads (uuid names) and create a job;
   - a worker pool of `JOB_WORKERS` consumes the engine's NDJSON;
   - progress goes to an SSE hub (`/api/jobs/{id}/stream?ticket=`);
   - the result is stored: document, figures, suggestions, `ai_calls`;
   - engine errors are mapped to the API error codes.
5. **Live** (`/ws/live?ticket=`, SPEC §9.5):
   - binary frames parsed with the 8-byte header;
   - an ordered queue per session with drop-oldest after 3 waiting;
   - chunks posted to the engine, captions sent back;
   - on stop / 15-minute cap / disconnect: save segments, create the transcript document, send `saved`;
   - `live_busy` when more than 3 sessions are active.
6. **Static:** serve `web/dist` with SPA fallback; long cache for hashed assets; no cache for `index.html`.

## Acceptance (from the 30 Oct browser test; each needs a Go test)
1. Engine 401 → `/api/health` reports `modelscope: invalid_token`; AI endpoints return 503 `modelscope_token_invalid`.
2. A question title under 10 or over 150 characters → 422 with `title_length`.
3. Saving an event succeeds, with a test asserting the exact INSERT column list.
4. A panic in any handler returns the error JSON; the stack trace goes only to the log.
5. Register without terms → `terms_required`.
6. `end_at` ≤ `start_at` → 422 `end_before_start`.

## Done when
- [ ] `go test ./...` and `go vet` pass; contract validation is green for every endpoint.
- [ ] Load check: 20 concurrent users hitting dashboard + forum list (e.g. with `hey`) at p95 < 200 ms on the free CPU tier, with no SQLite lock errors.
- [ ] A job runs end to end against the real engine and shows its stages over SSE.

**Gate, Sat 31 Oct 22:00.** If auth, events and forum are not green by then, stop and tell me. Plan B: the engine serves the public API by reusing the old Python `services/` (same `openapi.yaml`, so the web app is unaffected), and Go is dropped.
